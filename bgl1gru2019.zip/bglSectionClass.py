class Section:
    def __init__(self):
        self.numberOfSubsections = 0
        self.kindOfSection = None
        self.subsections = []
        self.subsectionsDataOffsets = []
        self.subsectionData = []
    def readSubsectionDataFrom(self,rData,offset,i,bglStructure):
        pass
    def SelectClosestAirportTo(self,coordinates):
        pass
        
    def FindRecordsByAirportIcao(self,icao):
        pass
