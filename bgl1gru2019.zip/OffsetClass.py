class Offset:
    def __init__(self,val):
        self.val = val
